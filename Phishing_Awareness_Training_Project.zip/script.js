
function checkAnswer(isPhishing) {
    const result = document.getElementById("result");
    if (isPhishing) {
        result.innerText = "Correct! This is a phishing attempt.";
        result.style.color = "green";
    } else {
        result.innerText = "Incorrect. Look for warning signs like urgency and fake links.";
        result.style.color = "red";
    }
}
