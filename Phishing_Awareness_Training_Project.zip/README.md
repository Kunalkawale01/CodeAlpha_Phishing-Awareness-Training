
# Phishing Awareness Training Module

## How to Run
1. Unzip the folder
2. Open index.html in a browser

## Features
- Phishing awareness content
- Social engineering explanation
- Real-world example
- Interactive puzzle
